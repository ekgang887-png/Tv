package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Channel
import com.example.data.model.NavTab
import com.example.player.TvPlayerManager
import com.example.ui.components.ChannelCard
import com.example.ui.components.TvLivePlayer
import com.example.ui.components.WHATSAPP_CHANNEL_URL
import com.example.ui.components.openExternalUrl
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SkyAccent
import com.example.ui.theme.Slate300
import com.example.ui.theme.Slate400

@Composable
fun HomeScreen(
    activeChannel: Channel?,
    featuredChannels: List<Channel>,
    playerManager: TvPlayerManager,
    onChannelSelect: (Channel) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onNavigateTab: (NavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 160.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
            .testTag("home_screen_grid")
    ) {
        // Hero Live TV Theater Banner
        item(span = { GridItemSpan(maxLineSpan) }) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF071228)),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0x4400F2FE), RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Badge
                    Surface(
                        color = Color(0xFF042F3E),
                        shape = RoundedCornerShape(20.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x5500F2FE))
                    ) {
                        Text(
                            text = "✨ PREMIUM BROADCAST NETWORK",
                            color = CyanNeon,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    // Title
                    Column {
                        Text(
                            text = "WORLDWIDE",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "LIVE TV",
                            color = CyanNeon,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Text(
                        text = "Stream thousands of free-to-air international live television channels with low-latency HLS playback and zero subscription fees.",
                        color = Slate300,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )

                    // Hero Live Video Player
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.5.dp, Color(0x5500F2FE), RoundedCornerShape(16.dp))
                    ) {
                        TvLivePlayer(
                            playerManager = playerManager,
                            channel = activeChannel,
                            modifier = Modifier.fillMaxSize(),
                            onFullscreenToggle = { onNavigateTab(NavTab.LIVE) }
                        )
                    }

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onNavigateTab(NavTab.LIVE) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyanNeon,
                                contentColor = Color(0xFF030712)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("launch_theater_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.size(6.dp))
                            Text(
                                text = "Live Theater",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }

                        OutlinedButton(
                            onClick = { onNavigateTab(NavTab.CHANNELS) },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color.White
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("browse_channels_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tv,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.size(6.dp))
                            Text(
                                text = "All Channels",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Official WhatsApp Channel Banner
        item(span = { GridItemSpan(maxLineSpan) }) {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF062A1F)),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, EmeraldGreen.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
                    .clickable { openExternalUrl(context, WHATSAPP_CHANNEL_URL) }
                    .testTag("whatsapp_home_banner")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Official RW TV WhatsApp Channel",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Get live schedule alerts and new station updates.",
                            color = EmeraldGreen.copy(alpha = 0.9f),
                            fontSize = 11.sp
                        )
                    }

                    Surface(
                        color = EmeraldGreen,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "Join ➔",
                            color = Color(0xFF030712),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // Featured Worldwide Broadcasts Header
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "🔥 Featured Worldwide Broadcasts",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                TextButton(onClick = { onNavigateTab(NavTab.CHANNELS) }) {
                    Text(
                        text = "Explore All ➔",
                        color = CyanNeon,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Featured Channel Cards Grid
        items(featuredChannels, key = { it.id }) { channel ->
            ChannelCard(
                channel = channel,
                isSelected = activeChannel?.id == channel.id,
                onSelect = { onChannelSelect(channel) },
                onToggleFavorite = { onToggleFavorite(channel.id) }
            )
        }

        // Bottom spacing
        item(span = { GridItemSpan(maxLineSpan) }) {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
