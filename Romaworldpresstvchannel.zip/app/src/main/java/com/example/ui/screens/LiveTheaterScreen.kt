package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Channel
import com.example.player.TvPlayerManager
import com.example.ui.components.TvLivePlayer
import com.example.ui.components.WHATSAPP_CHANNEL_URL
import com.example.ui.components.openExternalUrl
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.RoseLive
import com.example.ui.theme.Slate400

@Composable
fun LiveTheaterScreen(
    activeChannel: Channel?,
    allChannels: List<Channel>,
    playerManager: TvPlayerManager,
    onChannelSelect: (Channel) -> Unit,
    onToggleFavorite: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var guideSearchQuery by remember { mutableStateOf("") }

    val filteredGuide = remember(allChannels, guideSearchQuery) {
        if (guideSearchQuery.isBlank()) {
            allChannels
        } else {
            val q = guideSearchQuery.trim().lowercase()
            allChannels.filter {
                it.name.lowercase().contains(q) ||
                it.country.lowercase().contains(q) ||
                it.category.lowercase().contains(q)
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
            .testTag("live_theater_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Big Cinematic Player Box
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.5.dp, Color(0x6600F2FE), RoundedCornerShape(20.dp))
            ) {
                TvLivePlayer(
                    playerManager = playerManager,
                    channel = activeChannel,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // Active Channel Information & Actions Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkCardBorder, RoundedCornerShape(18.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = activeChannel?.name ?: "No Station Selected",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${activeChannel?.country ?: "Global"} • ${activeChannel?.category ?: "General"}",
                            color = Slate400,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Favorite button
                        Surface(
                            color = if (activeChannel?.isFavorite == true) RoseLive.copy(alpha = 0.2f) else Color(0xFF0F1A34),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (activeChannel?.isFavorite == true) RoseLive else DarkCardBorder
                            ),
                            modifier = Modifier
                                .clickable {
                                    activeChannel?.let { onToggleFavorite(it.id) }
                                }
                                .testTag("theater_favorite_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = if (activeChannel?.isFavorite == true) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = null,
                                    tint = if (activeChannel?.isFavorite == true) RoseLive else Slate400,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = if (activeChannel?.isFavorite == true) "Favorited" else "Favorite",
                                    color = if (activeChannel?.isFavorite == true) RoseLive else Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // WhatsApp Channel quick jump
                        IconButton(
                            onClick = { openExternalUrl(context, WHATSAPP_CHANNEL_URL) },
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF062A1F))
                                .border(1.dp, EmeraldGreen.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        ) {
                            Text(text = "💬", fontSize = 16.sp)
                        }
                    }
                }
            }
        }

        // Channel Guide Header & Search
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "📋 Interactive Channel Guide",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${filteredGuide.size} Stations",
                        color = CyanNeon,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                OutlinedTextField(
                    value = guideSearchQuery,
                    onValueChange = { guideSearchQuery = it },
                    placeholder = { Text("Filter guide channels...", fontSize = 12.sp, color = Slate400) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = CyanNeon,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF060D1D),
                        unfocusedContainerColor = Color(0xFF060D1D),
                        focusedBorderColor = CyanNeon,
                        unfocusedBorderColor = Color(0xFF1E293B),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("guide_search_field")
                )
            }
        }

        // Guide List
        items(filteredGuide, key = { it.id }) { channel ->
            val isPlaying = activeChannel?.id == channel.id

            Surface(
                color = if (isPlaying) Color(0xFF042F3E) else DarkSurface,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isPlaying) CyanNeon else Color(0xFF162544)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onChannelSelect(channel) }
                    .testTag("guide_item_${channel.id}")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = if (isPlaying) "▶" else "📺",
                            fontSize = 14.sp
                        )
                        Column {
                            Text(
                                text = channel.name,
                                color = if (isPlaying) CyanNeon else Color.White,
                                fontSize = 13.sp,
                                fontWeight = if (isPlaying) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = channel.category,
                                color = Slate400,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Surface(
                        color = Color(0xFF020617),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = channel.country,
                            color = CyanNeon,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
