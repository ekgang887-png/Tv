package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RomanTvColorScheme = darkColorScheme(
    primary = CyanNeon,
    onPrimary = DarkBg,
    primaryContainer = Color(0xFF042F3E),
    onPrimaryContainer = CyanNeon,
    secondary = SkyAccent,
    onSecondary = DarkBg,
    secondaryContainer = Color(0xFF0C2B4E),
    onSecondaryContainer = SkyAccent,
    tertiary = EmeraldGreen,
    onTertiary = Color.Black,
    error = RoseLive,
    onError = Color.White,
    background = DarkBg,
    onBackground = Slate100,
    surface = DarkSurface,
    onSurface = Slate100,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = Slate300,
    outline = Slate700,
    outlineVariant = DarkCardBorder
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RomanTvColorScheme,
        typography = Typography,
        content = content
    )
}
