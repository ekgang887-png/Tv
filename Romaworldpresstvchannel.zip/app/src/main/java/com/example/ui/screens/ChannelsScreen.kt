package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CategoryCount
import com.example.data.model.Channel
import com.example.data.model.CountryCount
import com.example.ui.components.ChannelCard
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.Slate400

@Composable
fun ChannelsScreen(
    channels: List<Channel>,
    activeChannel: Channel?,
    searchQuery: String,
    selectedCountry: String,
    selectedCategory: String,
    activeStreamsOnly: Boolean,
    countries: List<CountryCount>,
    categories: List<CategoryCount>,
    onChannelSelect: (Channel) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onSearchChanged: (String) -> Unit,
    onCountrySelected: (String) -> Unit,
    onCategorySelected: (String) -> Unit,
    onToggleActiveStreams: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var countryMenuExpanded by remember { mutableStateOf(false) }
    var categoryMenuExpanded by remember { mutableStateOf(false) }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 160.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
            .testTag("channels_screen_grid")
    ) {
        // Search & Filter Panel
        item(span = { GridItemSpan(maxLineSpan) }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkCardBorder, RoundedCornerShape(20.dp))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Search bar
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchChanged,
                        placeholder = { Text("Search by name, country, or genre...", color = Slate400, fontSize = 12.sp) },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(18.dp))
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchChanged("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Slate400, modifier = Modifier.size(18.dp))
                                }
                            }
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF060D1D),
                            unfocusedContainerColor = Color(0xFF060D1D),
                            focusedBorderColor = CyanNeon,
                            unfocusedBorderColor = Color(0xFF1E293B),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("channel_search_input")
                    )

                    // Filters Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Country dropdown button
                        Box(modifier = Modifier.weight(1f)) {
                            Surface(
                                color = Color(0xFF060D1D),
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { countryMenuExpanded = true }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (selectedCountry == "ALL") "All Countries" else "🌐 $selectedCountry",
                                        color = if (selectedCountry != "ALL") CyanNeon else Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text("▼", color = Slate400, fontSize = 10.sp)
                                }
                            }

                            DropdownMenu(
                                expanded = countryMenuExpanded,
                                onDismissRequest = { countryMenuExpanded = false },
                                modifier = Modifier.background(DarkSurface)
                            ) {
                                DropdownMenuItem(
                                    text = { Text("All Countries", color = Color.White) },
                                    onClick = {
                                        onCountrySelected("ALL")
                                        countryMenuExpanded = false
                                    }
                                )
                                countries.take(25).forEach { c ->
                                    DropdownMenuItem(
                                        text = { Text("${c.countryCode} (${c.count})", color = Color.White) },
                                        onClick = {
                                            onCountrySelected(c.countryCode)
                                            countryMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Category dropdown button
                        Box(modifier = Modifier.weight(1f)) {
                            Surface(
                                color = Color(0xFF060D1D),
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { categoryMenuExpanded = true }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (selectedCategory == "ALL") "All Categories" else "📑 $selectedCategory",
                                        color = if (selectedCategory != "ALL") CyanNeon else Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text("▼", color = Slate400, fontSize = 10.sp)
                                }
                            }

                            DropdownMenu(
                                expanded = categoryMenuExpanded,
                                onDismissRequest = { categoryMenuExpanded = false },
                                modifier = Modifier.background(DarkSurface)
                            ) {
                                DropdownMenuItem(
                                    text = { Text("All Categories", color = Color.White) },
                                    onClick = {
                                        onCategorySelected("ALL")
                                        categoryMenuExpanded = false
                                    }
                                )
                                categories.take(20).forEach { cat ->
                                    DropdownMenuItem(
                                        text = { Text("${cat.category} (${cat.count})", color = Color.White) },
                                        onClick = {
                                            onCategorySelected(cat.category)
                                            categoryMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Active Streams only toggle
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onToggleActiveStreams(!activeStreamsOnly) },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Checkbox(
                            checked = activeStreamsOnly,
                            onCheckedChange = onToggleActiveStreams,
                            colors = CheckboxDefaults.colors(
                                checkedColor = CyanNeon,
                                checkmarkColor = Color.Black,
                                uncheckedColor = Slate400
                            )
                        )
                        Text(
                            text = "Active Verified Streams Only",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Count header label
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Showing ${channels.size} Worldwide Channels",
                    color = Slate400,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                if (selectedCountry != "ALL" || selectedCategory != "ALL" || searchQuery.isNotEmpty()) {
                    Text(
                        text = "Reset Filters",
                        color = CyanNeon,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable {
                            onCountrySelected("ALL")
                            onCategorySelected("ALL")
                            onSearchChanged("")
                        }
                    )
                }
            }
        }

        // Channels List Grid
        if (channels.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No channels match your current filter.",
                        color = Slate400,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            items(channels, key = { it.id }) { channel ->
                ChannelCard(
                    channel = channel,
                    isSelected = activeChannel?.id == channel.id,
                    onSelect = { onChannelSelect(channel) },
                    onToggleFavorite = { onToggleFavorite(channel.id) }
                )
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
