package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBg = Color(0xFF030712)
val DarkSurface = Color(0xFF0B1326)
val DarkSurfaceElevated = Color(0xFF0F1A34)
val DarkCardBorder = Color(0x3300F2FE)

val CyanNeon = Color(0xFF00F2FE)
val SkyAccent = Color(0xFF38BDF8)
val EmeraldGreen = Color(0xFF10B981)
val RoseLive = Color(0xFFF43F5E)
val AmberStar = Color(0xFFFBBF24)

val Slate100 = Color(0xFFF1F5F9)
val Slate300 = Color(0xFFCBD5E1)
val Slate400 = Color(0xFF94A3B8)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)
val Slate950 = Color(0xFF020617)
