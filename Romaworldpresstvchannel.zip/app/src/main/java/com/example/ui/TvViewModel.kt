package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.FavoriteEntity
import com.example.data.local.HistoryEntity
import com.example.data.model.CategoryCount
import com.example.data.model.Channel
import com.example.data.model.CountryCount
import com.example.data.model.NavTab
import com.example.data.remote.ChannelRepository
import com.example.data.remote.CuratedChannels
import com.example.player.PlayerStatus
import com.example.player.TvPlayerManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class TvUiState(
    val selectedTab: NavTab = NavTab.HOME,
    val activeChannel: Channel? = CuratedChannels.list.firstOrNull(),
    val allChannels: List<Channel> = CuratedChannels.list,
    val featuredChannels: List<Channel> = CuratedChannels.list.take(8),
    val filteredChannels: List<Channel> = CuratedChannels.list,
    val searchQuery: String = "",
    val selectedCountry: String = "ALL",
    val selectedCategory: String = "ALL",
    val activeStreamsOnly: Boolean = true,
    val favoriteIds: Set<String> = setOf("nasa-tv", "dw-news-en", "red-bull-tv"),
    val favorites: List<Channel> = emptyList(),
    val history: List<Channel> = emptyList(),
    val countries: List<CountryCount> = emptyList(),
    val categories: List<CategoryCount> = emptyList(),
    val isSyncing: Boolean = false,
    val syncStatusText: String = "Live"
)

class TvViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val dao = database.channelDao()
    private val repository = ChannelRepository()

    val playerManager = TvPlayerManager(application)

    private val _selectedTab = MutableStateFlow(NavTab.HOME)
    private val _activeChannel = MutableStateFlow<Channel?>(CuratedChannels.list.firstOrNull())
    private val _allChannels = MutableStateFlow<List<Channel>>(CuratedChannels.list)
    private val _searchQuery = MutableStateFlow("")
    private val _selectedCountry = MutableStateFlow("ALL")
    private val _selectedCategory = MutableStateFlow("ALL")
    private val _activeStreamsOnly = MutableStateFlow(true)
    private val _isSyncing = MutableStateFlow(false)
    private val _syncStatusText = MutableStateFlow("${CuratedChannels.list.size} Curated")

    private val favoritesFlow = dao.getAllFavorites()
    private val historyFlow = dao.getAllHistory()

    val uiState: StateFlow<TvUiState> = combine(
        _selectedTab,
        _activeChannel,
        _allChannels,
        _searchQuery,
        _selectedCountry,
        _selectedCategory,
        _activeStreamsOnly,
        _isSyncing,
        _syncStatusText,
        favoritesFlow,
        historyFlow
    ) { params ->
        val tab = params[0] as NavTab
        val active = params[1] as Channel?
        val all = params[2] as List<Channel>
        val query = params[3] as String
        val country = params[4] as String
        val category = params[5] as String
        val streamOnly = params[6] as Boolean
        val syncing = params[7] as Boolean
        val syncText = params[8] as String
        val favEntities = params[9] as List<FavoriteEntity>
        val histEntities = params[10] as List<HistoryEntity>

        val favIdSet = favEntities.map { it.channelId }.toSet().ifEmpty {
            setOf("nasa-tv", "dw-news-en", "red-bull-tv")
        }

        val enrichedAll = all.map { ch ->
            ch.copy(isFavorite = favIdSet.contains(ch.id))
        }

        val activeEnriched = active?.let { ch ->
            ch.copy(isFavorite = favIdSet.contains(ch.id))
        }

        val filtered = enrichedAll.filter { ch ->
            if (streamOnly && ch.url.isBlank()) return@filter false
            if (country != "ALL" && !ch.country.equals(country, ignoreCase = true)) return@filter false
            if (category != "ALL" && !ch.category.equals(category, ignoreCase = true)) return@filter false
            if (query.isNotBlank()) {
                val q = query.trim().lowercase()
                val matchName = ch.name.lowercase().contains(q)
                val matchCountry = ch.country.lowercase().contains(q)
                val matchCat = ch.category.lowercase().contains(q)
                if (!matchName && !matchCountry && !matchCat) return@filter false
            }
            true
        }

        val favChannels = enrichedAll.filter { favIdSet.contains(it.id) }
        val historyChannels = histEntities.map { h ->
            enrichedAll.find { it.id == h.channelId } ?: Channel(
                id = h.channelId,
                name = h.channelName,
                country = h.country,
                category = h.category,
                logo = h.logo,
                url = h.streamUrl,
                isFavorite = favIdSet.contains(h.channelId)
            )
        }

        val countryMap = enrichedAll.groupBy { it.country }
        val countries = countryMap.map { (c, list) -> CountryCount(c, list.size) }
            .sortedByDescending { it.count }

        val categoryMap = enrichedAll.groupBy { it.category }
        val categories = categoryMap.map { (cat, list) -> CategoryCount(cat, list.size) }
            .sortedByDescending { it.count }

        TvUiState(
            selectedTab = tab,
            activeChannel = activeEnriched,
            allChannels = enrichedAll,
            featuredChannels = enrichedAll.take(8),
            filteredChannels = filtered,
            searchQuery = query,
            selectedCountry = country,
            selectedCategory = category,
            activeStreamsOnly = streamOnly,
            favoriteIds = favIdSet,
            favorites = favChannels,
            history = historyChannels,
            countries = countries,
            categories = categories,
            isSyncing = syncing,
            syncStatusText = syncText
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        TvUiState()
    )

    init {
        // Start playing default NASA TV channel
        _activeChannel.value?.let { ch ->
            playerManager.playStream(ch.url)
        }

        // Initialize default favorites in database if empty
        viewModelScope.launch {
            setOf("nasa-tv", "dw-news-en", "red-bull-tv").forEach { id ->
                dao.insertFavorite(FavoriteEntity(channelId = id))
            }
        }

        refreshData()
    }

    fun switchTab(tab: NavTab) {
        _selectedTab.value = tab
    }

    fun playChannel(channel: Channel) {
        _activeChannel.value = channel
        playerManager.playStream(channel.url)

        viewModelScope.launch {
            dao.recordHistory(
                HistoryEntity(
                    channelId = channel.id,
                    channelName = channel.name,
                    country = channel.country,
                    category = channel.category,
                    logo = channel.logo,
                    streamUrl = channel.url
                )
            )
        }
    }

    fun toggleFavorite(channelId: String) {
        viewModelScope.launch {
            val currentFavs = uiState.value.favoriteIds
            if (currentFavs.contains(channelId)) {
                dao.deleteFavorite(channelId)
            } else {
                dao.insertFavorite(FavoriteEntity(channelId = channelId))
            }
        }
    }

    fun clearFavorites() {
        viewModelScope.launch {
            dao.clearFavorites()
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            dao.clearHistory()
        }
    }

    fun setSearchQuery(q: String) {
        _searchQuery.value = q
    }

    fun selectCountry(country: String) {
        _selectedCountry.value = country
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun toggleActiveStreamsOnly(checked: Boolean) {
        _activeStreamsOnly.value = checked
    }

    fun refreshData() {
        viewModelScope.launch {
            _isSyncing.value = true
            _syncStatusText.value = "Syncing live directory..."
            try {
                val fetched = repository.fetchOnlineChannels()
                if (fetched.isNotEmpty()) {
                    _allChannels.value = fetched
                    _syncStatusText.value = "${fetched.size} Channels"
                } else {
                    _syncStatusText.value = "${CuratedChannels.list.size} Curated"
                }
            } catch (e: Exception) {
                _syncStatusText.value = "${CuratedChannels.list.size} Curated"
            } finally {
                _isSyncing.value = false
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        playerManager.release()
    }
}
