package com.example.player

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.datasource.DefaultHttpDataSource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class PlayerStatus {
    IDLE,
    BUFFERING,
    READY,
    ENDED,
    ERROR
}

@OptIn(UnstableApi::class)
class TvPlayerManager(private val context: Context) {
    val player: ExoPlayer = ExoPlayer.Builder(context).build().apply {
        playWhenReady = true
        repeatMode = Player.REPEAT_MODE_OFF
    }

    private val _status = MutableStateFlow(PlayerStatus.IDLE)
    val status: StateFlow<PlayerStatus> = _status.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private var currentUrl: String? = null

    init {
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_IDLE -> _status.value = PlayerStatus.IDLE
                    Player.STATE_BUFFERING -> _status.value = PlayerStatus.BUFFERING
                    Player.STATE_READY -> {
                        _status.value = PlayerStatus.READY
                        _isPlaying.value = player.playWhenReady
                    }
                    Player.STATE_ENDED -> {
                        _status.value = PlayerStatus.ENDED
                        _isPlaying.value = false
                    }
                }
            }

            override fun onIsPlayingChanged(isPlayingNow: Boolean) {
                _isPlaying.value = isPlayingNow
            }

            override fun onPlayerError(error: PlaybackException) {
                _status.value = PlayerStatus.ERROR
                _errorMessage.value = error.localizedMessage ?: "Stream connection error"
            }
        })
    }

    fun playStream(url: String) {
        if (url.isBlank()) {
            _status.value = PlayerStatus.ERROR
            _errorMessage.value = "No stream URL available for this channel."
            return
        }

        currentUrl = url
        _errorMessage.value = null
        _status.value = PlayerStatus.BUFFERING

        try {
            val dataSourceFactory = DefaultHttpDataSource.Factory()
                .setUserAgent("Mozilla/5.0 (Linux; Android 14) RomanWorldwideTV/1.0")
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(15000)
                .setAllowCrossProtocolRedirects(true)

            val mediaItem = MediaItem.Builder()
                .setUri(url)
                .build()

            val mediaSource = if (url.contains(".m3u8", ignoreCase = true)) {
                HlsMediaSource.Factory(dataSourceFactory)
                    .setAllowChunklessPreparation(true)
                    .createMediaSource(mediaItem)
            } else {
                androidx.media3.exoplayer.source.DefaultMediaSourceFactory(dataSourceFactory)
                    .createMediaSource(mediaItem)
            }

            player.setMediaSource(mediaSource)
            player.prepare()
            player.playWhenReady = true
        } catch (e: Exception) {
            _status.value = PlayerStatus.ERROR
            _errorMessage.value = e.message ?: "Failed to initialize stream"
        }
    }

    fun togglePlayPause() {
        if (player.isPlaying) {
            player.pause()
            _isPlaying.value = false
        } else {
            player.play()
            _isPlaying.value = true
        }
    }

    fun toggleMute() {
        val newMuted = !_isMuted.value
        _isMuted.value = newMuted
        player.volume = if (newMuted) 0f else 1f
    }

    fun reload() {
        currentUrl?.let { playStream(it) }
    }

    fun release() {
        player.release()
    }
}
