package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.NavTab
import com.example.ui.TvViewModel
import com.example.ui.components.AppBottomBar
import com.example.ui.components.AppTopHeader
import com.example.ui.components.FloatingSupportButton
import com.example.ui.components.MoreMenuDialog
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.CategoriesScreen
import com.example.ui.screens.ChannelsScreen
import com.example.ui.screens.CountriesScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LiveTheaterScreen
import com.example.ui.screens.RecentScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.DarkBg
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                RomanWorldwideTvApp()
            }
        }
    }
}

@Composable
fun RomanWorldwideTvApp(
    viewModel: TvViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var isMoreMenuOpen by remember { mutableStateOf(false) }

    // Android back navigation handler: return to HOME if currently on another tab
    BackHandler(enabled = uiState.selectedTab != NavTab.HOME) {
        viewModel.switchTab(NavTab.HOME)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        Scaffold(
            containerColor = DarkBg,
            topBar = {
                AppTopHeader(
                    channelCount = uiState.allChannels.size,
                    isSyncing = uiState.isSyncing,
                    onRefresh = { viewModel.refreshData() },
                    onSearchClick = { viewModel.switchTab(NavTab.SEARCH) },
                    onOpenMoreMenu = { isMoreMenuOpen = true }
                )
            },
            bottomBar = {
                AppBottomBar(
                    currentTab = uiState.selectedTab,
                    onTabSelected = { viewModel.switchTab(it) },
                    favoriteCount = uiState.favorites.size,
                    onOpenMoreMenu = { isMoreMenuOpen = true }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (uiState.selectedTab) {
                    NavTab.HOME -> {
                        HomeScreen(
                            activeChannel = uiState.activeChannel,
                            featuredChannels = uiState.featuredChannels,
                            playerManager = viewModel.playerManager,
                            onChannelSelect = { channel ->
                                viewModel.playChannel(channel)
                            },
                            onToggleFavorite = { id -> viewModel.toggleFavorite(id) },
                            onNavigateTab = { tab -> viewModel.switchTab(tab) }
                        )
                    }

                    NavTab.LIVE -> {
                        LiveTheaterScreen(
                            activeChannel = uiState.activeChannel,
                            allChannels = uiState.allChannels,
                            playerManager = viewModel.playerManager,
                            onChannelSelect = { channel -> viewModel.playChannel(channel) },
                            onToggleFavorite = { id -> viewModel.toggleFavorite(id) }
                        )
                    }

                    NavTab.CHANNELS -> {
                        ChannelsScreen(
                            channels = uiState.filteredChannels,
                            activeChannel = uiState.activeChannel,
                            searchQuery = uiState.searchQuery,
                            selectedCountry = uiState.selectedCountry,
                            selectedCategory = uiState.selectedCategory,
                            activeStreamsOnly = uiState.activeStreamsOnly,
                            countries = uiState.countries,
                            categories = uiState.categories,
                            onChannelSelect = { channel ->
                                viewModel.playChannel(channel)
                                viewModel.switchTab(NavTab.LIVE)
                            },
                            onToggleFavorite = { id -> viewModel.toggleFavorite(id) },
                            onSearchChanged = { q -> viewModel.setSearchQuery(q) },
                            onCountrySelected = { c -> viewModel.selectCountry(c) },
                            onCategorySelected = { cat -> viewModel.selectCategory(cat) },
                            onToggleActiveStreams = { s -> viewModel.toggleActiveStreamsOnly(s) }
                        )
                    }

                    NavTab.COUNTRIES -> {
                        CountriesScreen(
                            countries = uiState.countries,
                            onSelectCountry = { country ->
                                viewModel.selectCountry(country)
                                viewModel.switchTab(NavTab.CHANNELS)
                            }
                        )
                    }

                    NavTab.CATEGORIES -> {
                        CategoriesScreen(
                            categories = uiState.categories,
                            onSelectCategory = { cat ->
                                viewModel.selectCategory(cat)
                                viewModel.switchTab(NavTab.CHANNELS)
                            }
                        )
                    }

                    NavTab.FAVORITES -> {
                        FavoritesScreen(
                            favorites = uiState.favorites,
                            activeChannel = uiState.activeChannel,
                            onChannelSelect = { channel ->
                                viewModel.playChannel(channel)
                                viewModel.switchTab(NavTab.LIVE)
                            },
                            onToggleFavorite = { id -> viewModel.toggleFavorite(id) },
                            onClearFavorites = { viewModel.clearFavorites() }
                        )
                    }

                    NavTab.RECENT -> {
                        RecentScreen(
                            history = uiState.history,
                            activeChannel = uiState.activeChannel,
                            onChannelSelect = { channel ->
                                viewModel.playChannel(channel)
                                viewModel.switchTab(NavTab.LIVE)
                            },
                            onToggleFavorite = { id -> viewModel.toggleFavorite(id) },
                            onClearHistory = { viewModel.clearHistory() }
                        )
                    }

                    NavTab.SEARCH -> {
                        SearchScreen(
                            searchQuery = uiState.searchQuery,
                            onSearchChanged = { q -> viewModel.setSearchQuery(q) },
                            channels = uiState.filteredChannels,
                            activeChannel = uiState.activeChannel,
                            onChannelSelect = { channel ->
                                viewModel.playChannel(channel)
                                viewModel.switchTab(NavTab.LIVE)
                            },
                            onToggleFavorite = { id -> viewModel.toggleFavorite(id) }
                        )
                    }

                    NavTab.SETTINGS -> {
                        SettingsScreen(
                            syncStatusText = uiState.syncStatusText,
                            onRefreshData = { viewModel.refreshData() },
                            onClearFavorites = { viewModel.clearFavorites() },
                            onClearHistory = { viewModel.clearHistory() }
                        )
                    }

                    NavTab.ABOUT -> {
                        AboutScreen()
                    }
                }

                // Floating WhatsApp Developer Support button (hidden in full Live Theater screen)
                if (uiState.selectedTab != NavTab.LIVE) {
                    FloatingSupportButton(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 16.dp, bottom = 16.dp)
                    )
                }
            }
        }

        // More Navigation Destinations Dialog
        if (isMoreMenuOpen) {
            MoreMenuDialog(
                currentTab = uiState.selectedTab,
                onTabSelected = { viewModel.switchTab(it) },
                onDismiss = { isMoreMenuOpen = false }
            )
        }
    }
}
