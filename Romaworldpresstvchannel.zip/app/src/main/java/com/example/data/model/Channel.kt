package com.example.data.model

data class Channel(
    val id: String,
    val name: String,
    val country: String = "GLOBAL",
    val category: String = "General",
    val logo: String = "",
    val url: String = "",
    val isCurated: Boolean = false,
    val isFavorite: Boolean = false
)

enum class NavTab(val title: String, val iconLabel: String) {
    HOME("Home", "🏠"),
    LIVE("Live TV", "📡"),
    CHANNELS("Channels", "📺"),
    COUNTRIES("Countries", "🌐"),
    CATEGORIES("Categories", "📑"),
    FAVORITES("Favorites", "❤️"),
    RECENT("Recent", "🕒"),
    SEARCH("Search", "🔍"),
    SETTINGS("Settings", "⚙️"),
    ABOUT("About", "ℹ️")
}

data class CountryCount(
    val countryCode: String,
    val count: Int
)

data class CategoryCount(
    val category: String,
    val count: Int
)
