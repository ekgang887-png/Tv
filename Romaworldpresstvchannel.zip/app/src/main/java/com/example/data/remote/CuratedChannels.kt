package com.example.data.remote

import com.example.data.model.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object CuratedChannels {
    val list: List<Channel> = listOf(
        Channel(
            id = "nasa-tv",
            name = "NASA TV Live HD",
            country = "US",
            category = "Science",
            logo = "https://upload.wikimedia.org/wikipedia/commons/e/e5/NASA_logo.svg",
            url = "https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8",
            isCurated = true
        ),
        Channel(
            id = "dw-news-en",
            name = "DW News English",
            country = "DE",
            category = "News",
            logo = "https://upload.wikimedia.org/wikipedia/commons/7/75/Deutsche_Welle_symbol_2012.svg",
            url = "https://dwamdstream102.akamaized.net/hls/live/2015525/dwstream102/index.m3u8",
            isCurated = true
        ),
        Channel(
            id = "france24-en",
            name = "France 24 English",
            country = "FR",
            category = "News",
            logo = "https://upload.wikimedia.org/wikipedia/en/6/65/France_24_logo.svg",
            url = "https://static.france24.com/live/F24_EN_LO_HLS/live_tv.m3u8",
            isCurated = true
        ),
        Channel(
            id = "al-jazeera-en",
            name = "Al Jazeera English HD",
            country = "QA",
            category = "News",
            logo = "https://upload.wikimedia.org/wikipedia/en/f/f2/Al_Jazeera_English_logo.svg",
            url = "https://live-hls-web-aje.getaj.net/AJE/01.m3u8",
            isCurated = true
        ),
        Channel(
            id = "red-bull-tv",
            name = "Red Bull TV Sports",
            country = "AT",
            category = "Sports",
            logo = "https://upload.wikimedia.org/wikipedia/en/e/eb/Red_Bull_TV_logo.svg",
            url = "https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master.m3u8",
            isCurated = true
        ),
        Channel(
            id = "bloomberg-quicktake",
            name = "Bloomberg Quicktake",
            country = "US",
            category = "Business",
            logo = "https://upload.wikimedia.org/wikipedia/commons/6/6b/Bloomberg_Quicktake_logo.svg",
            url = "https://bloomberg-quicktake-1-eu.samsung.wurl.tv/playlist.m3u8",
            isCurated = true
        ),
        Channel(
            id = "cna-singapore",
            name = "CNA Channel NewsAsia",
            country = "SG",
            category = "News",
            logo = "https://upload.wikimedia.org/wikipedia/commons/e/e0/CNA_logo.svg",
            url = "https://cnalivetv.akamaized.net/hls/live/999882/live_tv/master.m3u8",
            isCurated = true
        ),
        Channel(
            id = "nhk-world-japan",
            name = "NHK World Japan",
            country = "JP",
            category = "Culture",
            logo = "https://upload.wikimedia.org/wikipedia/commons/7/7b/NHK_World-Japan_logo.svg",
            url = "https://b-nhkworld.akamaized.net/hls/live/2012351/nhkworld-tv/index.m3u8",
            isCurated = true
        ),
        Channel(
            id = "euronews-en",
            name = "Euronews Live HD",
            country = "FR",
            category = "News",
            logo = "https://upload.wikimedia.org/wikipedia/commons/4/47/Euronews_2016_logo.svg",
            url = "https://rakuten-euronews-1-eu.samsung.wurl.tv/playlist.m3u8",
            isCurated = true
        ),
        Channel(
            id = "weathernation-live",
            name = "WeatherNation HD",
            country = "US",
            category = "Weather",
            logo = "https://upload.wikimedia.org/wikipedia/en/b/be/WeatherNation_TV_logo.svg",
            url = "https://weathernation-live.akamaized.net/hls/live/592398/BoWN-US/master.m3u8",
            isCurated = true
        ),
        Channel(
            id = "trt-world",
            name = "TRT World HD",
            country = "TR",
            category = "News",
            logo = "https://upload.wikimedia.org/wikipedia/commons/f/f6/TRT_World_logo.svg",
            url = "https://tv-trtworld.medya.trt.com.tr/master.m3u8",
            isCurated = true
        ),
        Channel(
            id = "arirang-tv",
            name = "Arirang TV Korea",
            country = "KR",
            category = "Entertainment",
            logo = "https://upload.wikimedia.org/wikipedia/commons/3/30/Arirang_TV_logo.svg",
            url = "https://amdlive.ctnd.com.edgesuite.net/arirang_1ch/smil:arirang_1ch.smil/playlist.m3u8",
            isCurated = true
        ),
        Channel(
            id = "dw-espanol",
            name = "DW Español",
            country = "DE",
            category = "News",
            logo = "https://upload.wikimedia.org/wikipedia/commons/7/75/Deutsche_Welle_symbol_2012.svg",
            url = "https://dwamdstream104.akamaized.net/hls/live/2015530/dwstream104/index.m3u8",
            isCurated = true
        ),
        Channel(
            id = "france24-fr",
            name = "France 24 Français",
            country = "FR",
            category = "News",
            logo = "https://upload.wikimedia.org/wikipedia/en/6/65/France_24_logo.svg",
            url = "https://static.france24.com/live/F24_FR_LO_HLS/live_tv.m3u8",
            isCurated = true
        ),
        Channel(
            id = "al-jazeera-ar",
            name = "Al Jazeera Arabic الجزيرة",
            country = "QA",
            category = "News",
            logo = "https://upload.wikimedia.org/wikipedia/en/f/f2/Al_Jazeera_English_logo.svg",
            url = "https://live-hls-web-aja.getaj.net/AJA/01.m3u8",
            isCurated = true
        ),
        Channel(
            id = "africanews-en",
            name = "Africanews HD",
            country = "CG",
            category = "News",
            logo = "https://upload.wikimedia.org/wikipedia/commons/d/da/Africanews_logo.svg",
            url = "https://rakuten-africanews-1-eu.samsung.wurl.tv/playlist.m3u8",
            isCurated = true
        ),
        Channel(
            id = "rtve-24h",
            name = "RTVE 24h Spain",
            country = "ES",
            category = "News",
            logo = "https://upload.wikimedia.org/wikipedia/commons/9/90/Canal_24_Horas_%282008%29.svg",
            url = "https://ztnr.rtve.es/ztnr/1694255.m3u8",
            isCurated = true
        ),
        Channel(
            id = "nasa-media",
            name = "NASA Operations & ISS",
            country = "US",
            category = "Science",
            logo = "https://upload.wikimedia.org/wikipedia/commons/e/e5/NASA_logo.svg",
            url = "https://ntv2.akamaized.net/hls/live/2013923/NASA-NTV2-HLS/master.m3u8",
            isCurated = true
        )
    )
}

class ChannelRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun fetchOnlineChannels(): List<Channel> = withContext(Dispatchers.IO) {
        val mergedList = CuratedChannels.list.toMutableList()
        val seenIds = CuratedChannels.list.map { it.id }.toMutableSet()

        try {
            // Fetch streams map: channel_id -> stream_url
            val streamsRequest = Request.Builder()
                .url("https://iptv-org.github.io/api/streams.json")
                .build()
            val streamsResponse = client.newCall(streamsRequest).execute()
            val streamMap = mutableMapOf<String, String>()

            if (streamsResponse.isSuccessful) {
                streamsResponse.body?.string()?.let { body ->
                    val arr = JSONArray(body)
                    for (i in 0 until minOf(arr.length(), 1500)) {
                        val obj = arr.getJSONObject(i)
                        val chId = obj.optString("channel")
                        val url = obj.optString("url")
                        if (chId.isNotEmpty() && url.isNotEmpty() && !streamMap.containsKey(chId)) {
                            streamMap[chId] = url
                        }
                    }
                }
            }

            // Fetch channel metadata
            val channelsRequest = Request.Builder()
                .url("https://iptv-org.github.io/api/channels.json")
                .build()
            val channelsResponse = client.newCall(channelsRequest).execute()

            if (channelsResponse.isSuccessful) {
                channelsResponse.body?.string()?.let { body ->
                    val arr = JSONArray(body)
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        val id = obj.optString("id")
                        val name = obj.optString("name")
                        val country = obj.optString("country").uppercase().ifEmpty { "GLOBAL" }
                        val categoriesArr = obj.optJSONArray("categories")
                        val category = if (categoriesArr != null && categoriesArr.length() > 0) {
                            categoriesArr.getString(0).replaceFirstChar { it.uppercase() }
                        } else {
                            "General"
                        }
                        val logo = obj.optString("logo")
                        val streamUrl = streamMap[id] ?: ""

                        // Only add if has active stream or valid entry and not already in curated
                        if (id.isNotEmpty() && name.isNotEmpty() && !seenIds.contains(id) && streamUrl.isNotEmpty()) {
                            seenIds.add(id)
                            mergedList.add(
                                Channel(
                                    id = id,
                                    name = name,
                                    country = country,
                                    category = category,
                                    logo = logo,
                                    url = streamUrl,
                                    isCurated = false
                                )
                            )
                        }
                        if (mergedList.size >= 120) break // Keep responsive and memory efficient
                    }
                }
            }
        } catch (_: Exception) {
            // Silently fallback to curated list on network failure
        }

        mergedList
    }
}
